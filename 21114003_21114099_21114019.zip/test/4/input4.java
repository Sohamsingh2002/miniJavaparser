public class input4 {
    public static void main(String[] args) {
        int a=0;
        foo(aa);
        int z=abc+abc;
        int l=this.akz;
        int pq=(50*20)-30;
        int obj=new ars();
        for (int i = 0; i <= 20; i++) {
            if (i % 2 == 0) {
                System.out.println(i + " is even");
            } else {
                System.out.println(i + " is odd");
            }
        }
    }
}