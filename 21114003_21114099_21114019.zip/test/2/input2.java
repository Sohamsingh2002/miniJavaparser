
public class input2 {
    public static void main(String[] args) {
        int n=25;
        int k=0;
        while(n>=0){
            n--;
            k++;
            k=k+1;
        }
        System.out.println(k);
    }
}
