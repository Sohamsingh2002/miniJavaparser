public class input1 {
    public static void main(String[] args) {
        int a=20;
        if(a==20){
            System.out.println("It's 20");
        }
        else{
            System.out.println("It's not 20");
        }
    }
}
